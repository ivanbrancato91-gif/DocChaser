import { NextResponse } from 'next/server'
import { rateLimit, requireSameOrigin } from '@/lib/security'
import { z } from 'zod'
import { createSupabaseServerClient } from '@/lib/supabase-server'
import { getSupabaseAdmin } from '@/lib/supabase-admin'

const bodySchema = z.object({ documentId: z.string().uuid() })
const MODEL = process.env.OPENAI_MODEL || 'gpt-5.6-luna'

const resultSchema = {
  type: 'object',
  additionalProperties: false,
  properties: {
    category: { type: 'string' },
    confidence: { type: 'number', minimum: 0, maximum: 1 },
    summary: { type: 'string' },
    fields: { type: 'object', additionalProperties: { type: 'string' } },
    warnings: { type: 'array', items: { type: 'string' } },
  },
  required: ['category', 'confidence', 'summary', 'fields', 'warnings'],
} as const

export async function POST(request: Request) {
  const originError=requireSameOrigin(request); if(originError)return originError
  const limited=rateLimit(request,'ai-analyze',12,60*60*1000); if(limited)return limited
  if (!process.env.OPENAI_API_KEY) return NextResponse.json({ ok: false, error: 'AI non configurata' }, { status: 503 })

  const parsed = bodySchema.safeParse(await request.json().catch(() => null))
  if (!parsed.success) return NextResponse.json({ ok: false, error: 'documentId non valido' }, { status: 400 })

  const server = await createSupabaseServerClient()
  const { data: { user } } = await server.auth.getUser()
  if (!user) return NextResponse.json({ ok: false, error: 'Autenticazione richiesta' }, { status: 401 })

  const admin = getSupabaseAdmin()
  if (!admin) return NextResponse.json({ ok: false, error: 'Storage server non configurato' }, { status: 503 })

  const { data: document, error: documentError } = await admin
    .from('documents')
    .select('id, organization_id, storage_path, original_name, mime_type, status, size_bytes')
    .eq('id', parsed.data.documentId)
    .maybeSingle()
  if (documentError || !document) return NextResponse.json({ ok: false, error: 'Documento non trovato' }, { status: 404 })
  if (document.size_bytes > 10 * 1024 * 1024) return NextResponse.json({ ok: false, error: 'Documento troppo grande per l’analisi AI' }, { status: 413 })

  const { data: membership } = await server
    .from('organization_members')
    .select('organization_id')
    .eq('organization_id', document.organization_id)
    .eq('user_id', user.id)
    .maybeSingle()
  if (!membership) return NextResponse.json({ ok: false, error: 'Non autorizzato' }, { status: 403 })

  const { data: file, error: downloadError } = await admin.storage.from('documents').download(document.storage_path)
  if (downloadError || !file) return NextResponse.json({ ok: false, error: 'Documento non disponibile' }, { status: 502 })

  const base64 = Buffer.from(await file.arrayBuffer()).toString('base64')
  const dataUrl = `data:${document.mime_type};base64,${base64}`
  const contentType = document.mime_type === 'application/pdf' ? 'input_file' : 'input_image'
  const media = contentType === 'input_file'
    ? { type: 'input_file', filename: document.original_name, file_data: dataUrl }
    : { type: 'input_image', image_url: dataUrl, detail: 'high' }

  const { data: job, error: jobError } = await admin.from('ai_jobs').insert({
    organization_id: document.organization_id,
    document_id: document.id,
    job_type: 'document_analysis',
    status: 'running',
    input: { model: MODEL, document_name: document.original_name },
  }).select('id').single()
  if (jobError || !job) return NextResponse.json({ ok: false, error: 'Impossibile creare il job AI' }, { status: 500 })

  try {
    const response = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: MODEL,
        input: [{
          role: 'user',
          content: [
            { type: 'input_text', text: 'Analizza questo documento in modo prudente. Classificalo e segnala possibili dati mancanti o incongruenze. Non decidere mai se il documento è accettato o rifiutato: il risultato è solo un supporto per un operatore umano.' },
            media,
          ],
        }],
        text: { format: { type: 'json_schema', name: 'document_analysis', strict: true, schema: resultSchema } },
      }),
    })

    const payload = await response.json()
    if (!response.ok) throw new Error(payload?.error?.message || 'OpenAI request failed')
    const output = JSON.parse(payload.output_text)

    await admin.from('documents').update({
      status: 'ai_review',
      ai_category: output.category,
      ai_confidence: output.confidence,
      ai_metadata: output,
    }).eq('id', document.id)

    await admin.from('ai_jobs').update({ status: 'completed', output, completed_at: new Date().toISOString() }).eq('id', job.id)
    return NextResponse.json({ ok: true, documentId: document.id, analysis: output })
  } catch (error) {
    const message = error instanceof Error ? error.message : 'AI analysis failed'
    await admin.from('ai_jobs').update({ status: 'failed', output: { error: message }, completed_at: new Date().toISOString() }).eq('id', job.id)
    return NextResponse.json({ ok: false, error: 'Analisi AI non riuscita' }, { status: 502 })
  }
}
