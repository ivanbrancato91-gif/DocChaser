'use client'
import { useEffect, useState } from 'react'
import Page from '@/components/Page'

const plans = [
  ['starter', 'Starter', '19 €/mese', 'Gestione documenti e pratiche'],
  ['studio', 'Studio', '39 €/mese', 'Funzionalità avanzate e automazioni'],
  ['team', 'Team', '79 €/mese', 'Funzionalità complete per team'],
] as const

type BillingData = { organization: { id:string; name:string }; subscription: { plan:string; status:string; current_period_end:string|null; stripe_customer_id:string|null }|null }

export default function Billing() {
  const [data,setData] = useState<BillingData|null>(null)
  const [busy,setBusy] = useState<string|null>(null)
  const [error,setError] = useState('')
  const [message,setMessage] = useState('')

  useEffect(() => { fetch('/api/billing').then(async r => { const d=await r.json(); if(!r.ok) throw new Error(d.error); setData(d) }).catch(e=>setError(e.message)) }, [])

  async function checkout(plan: string) {
    setBusy(plan); setError(''); setMessage('')
    try {
      const response = await fetch('/api/stripe/checkout', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({ plan }) })
      const d=await response.json(); if(!response.ok) throw new Error(d.error||'Checkout non disponibile'); window.location.href=d.url
    } catch(e) { setError(e instanceof Error ? e.message : 'Errore') } finally { setBusy(null) }
  }

  async function portal() {
    setBusy('portal'); setError(''); setMessage('')
    try { const r=await fetch('/api/billing/portal',{method:'POST'}); const d=await r.json(); if(!r.ok) throw new Error(d.error); window.location.href=d.url }
    catch(e){setError(e instanceof Error?e.message:'Errore')} finally{setBusy(null)}
  }

  const active=data?.subscription && ['active','trialing','past_due'].includes(data.subscription.status)
  return <Page title="Fatturazione" description="Gestisci il piano DocChaser e lo stato dell'abbonamento.">
    {data?.subscription && <div className="card" style={{marginBottom:18,display:'flex',justifyContent:'space-between',alignItems:'center',gap:18,flexWrap:'wrap'}}>
      <div><div className="muted">Piano attuale</div><h3 style={{margin:'5px 0'}}>{data.subscription.plan?.toUpperCase()} · <span className="badge green">{data.subscription.status}</span></h3>{data.subscription.current_period_end&&<div className="muted" style={{fontSize:12}}>Periodo fino al {new Date(data.subscription.current_period_end).toLocaleDateString('it-IT')}</div>}</div>
      {active && <button className="btn secondary" onClick={portal} disabled={busy==='portal'}>{busy==='portal'?'Apertura…':'Gestisci abbonamento'}</button>}
    </div>}
    <div className="grid3">{plans.map(([id,name,price,features])=><div className="card" key={id} style={{display:'flex',flexDirection:'column',gap:14}}><div><div className="muted">{name}</div><div style={{fontSize:28,fontWeight:800,margin:'4px 0'}}>{price}</div><div className="muted" style={{fontSize:13}}>{features}</div></div><button className="btn primary" onClick={()=>checkout(id)} disabled={busy!==null}>{busy===id?'Apertura…':data?.subscription?.plan===id?'Piano attuale':'Scegli piano'}</button></div>)}</div>
    <div className="card" style={{marginTop:18}}><b>Abbonamento sicuro</b><p className="muted" style={{marginBottom:0}}>I pagamenti sono gestiti da Stripe. Puoi aggiornare il metodo di pagamento, consultare le fatture o modificare l'abbonamento dal Customer Portal.</p></div>
    {error&&<p className="badge red" style={{marginTop:16}}>{error}</p>}{message&&<p className="badge green" style={{marginTop:16}}>{message}</p>}
  </Page>
}
