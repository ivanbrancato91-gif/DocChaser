'use client';
import Link from 'next/link';
import {useEffect,useState} from 'react';
import {usePathname} from 'next/navigation';
import {LayoutDashboard,FolderKanban,Users,Files,Clock3,UsersRound,CreditCard,Settings,ScrollText,Menu,Search,Bell,X,LogOut} from 'lucide-react';

const items=[['/dashboard','Dashboard',LayoutDashboard],['/cases','Pratiche',FolderKanban],['/clients','Clienti',Users],['/templates','Modelli',Files],['/reminders','Reminder',Clock3],['/team','Team',UsersRound],['/billing','Fatturazione',CreditCard],['/settings','Impostazioni',Settings],['/audit','Audit log',ScrollText]] as const;

export default function AppShell({children}:{children:React.ReactNode}){
  const path=usePathname();
  const [profile,setProfile]=useState<{full_name?:string|null;email?:string|null}>({});
  const [menuOpen,setMenuOpen]=useState(false);
  useEffect(()=>{fetch('/api/settings').then(r=>r.ok?r.json():null).then(d=>{if(d?.profile)setProfile(d.profile)}).catch(()=>{})},[]);
  useEffect(()=>{setMenuOpen(false)},[path]);
  useEffect(()=>{document.body.style.overflow=menuOpen?'hidden':'';return()=>{document.body.style.overflow=''}},[menuOpen]);
  const displayName=profile.full_name||profile.email?.split('@')[0]||'Utente';
  const initials=displayName.split(/\s+/).filter(Boolean).slice(0,2).map(x=>x[0]).join('').toUpperCase()||'DC';
  return <div className="shell">
    <aside className="sidebar"><div className="brand">Doc<span>Chaser</span></div><nav className="nav">{items.map(([href,label,Icon])=><Link key={href} className={path.startsWith(href)?'active':''} href={href}><Icon size={17}/>{label}</Link>)}</nav><div style={{position:'absolute',bottom:24,left:28,fontSize:12,color:'#64748b'}}>by Blue Harbor Studio</div></aside>
    {menuOpen&&<button aria-label="Chiudi menu" className="mobile-backdrop" onClick={()=>setMenuOpen(false)}/>} 
    <aside className={'mobile-drawer '+(menuOpen?'open':'')} aria-hidden={!menuOpen}>
      <div className="mobile-drawer-head"><div className="brand">Doc<span>Chaser</span></div><button className="icon-btn" aria-label="Chiudi menu" onClick={()=>setMenuOpen(false)}><X size={21}/></button></div>
      <nav className="nav">{items.map(([href,label,Icon])=><Link key={href} className={path.startsWith(href)?'active':''} href={href}><Icon size={18}/>{label}</Link>)}</nav>
      <div className="mobile-drawer-footer"><span>{displayName}</span><small>by Blue Harbor Studio</small></div>
    </aside>
    <main className="main"><header className="topbar">
      <button className="menu-btn" aria-label="Apri menu" onClick={()=>setMenuOpen(true)}><Menu size={21}/></button>
      <div className="search-box"><Search size={17} color="#64748b"/><input className="search" aria-label="Cerca" placeholder="Cerca clienti, pratiche, documenti..."/></div>
      <button className="icon-btn" aria-label="Notifiche"><Bell size={18}/></button>
      <div className="profile"><div title={displayName} className="avatar">{initials}</div><div className="mobile-profile-name">{displayName}</div></div>
    </header>{children}</main>
  </div>
}
