'use client'
import Page from '@/components/Page'
import { useEffect,useState } from 'react'
import { createClient } from '@/lib/supabase'

const labels:Record<string,string>={
 'document.approved':'Documento approvato','document.revision_requested':'Correzione richiesta','document.uploaded':'Documento caricato',
 'case.created':'Pratica creata','case.portal_sent':'Portale inviato','reminder.sent':'Reminder inviato','organization.settings_updated':'Impostazioni aggiornate',
 'team.member_added':'Membro aggiunto','team.member_role_changed':'Ruolo modificato','team.member_removed':'Membro rimosso',
 'stripe_billing_portal_opened':'Portale billing aperto','billing.plan_changed':'Piano modificato','billing.subscription_cancelled':'Abbonamento annullato','audit.retention_cleanup':'Pulizia audit'
}
export default function Security(){
 const [email,setEmail]=useState(''); const [role,setRole]=useState(''); const [events,setEvents]=useState<any[]>([]); const [filter,setFilter]=useState(''); const [busy,setBusy]=useState(false); const [msg,setMsg]=useState(''); const [err,setErr]=useState('')
 async function load(){const r=await fetch('/api/audit?limit=200'+(filter?'&type='+encodeURIComponent(filter):''));const d=await r.json();if(!r.ok)throw new Error(d.error);setEvents(d.events||[])}
 useEffect(()=>{load().catch(e=>setErr(e.message)); fetch('/api/settings').then(r=>r.json()).then(d=>{setEmail(d.profile?.email||'');setRole(d.role||'')}).catch(()=>{})},[filter])
 async function changePassword(){setBusy(true);setErr('');setMsg('');try{const supabase=createClient();const p=window.prompt('Nuova password (almeno 12 caratteri):')||'';if(!p)return;if(p.length<12)throw new Error('La password deve contenere almeno 12 caratteri.');const {error}=await supabase.auth.updateUser({password:p});if(error)throw error;setMsg('Password aggiornata.')}catch(e){setErr(e instanceof Error?e.message:'Errore')}finally{setBusy(false)}}
 async function cleanup(){if(role!=='owner'&&role!=='admin')return;if(!confirm('Eliminare gli eventi di audit più vecchi del periodo di conservazione?'))return;setBusy(true);try{const r=await fetch('/api/audit',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({days:365})});const d=await r.json();if(!r.ok)throw new Error(d.error);setMsg('Pulizia completata.');await load()}catch(e){setErr(e instanceof Error?e.message:'Errore')}finally{setBusy(false)}}
 function exportCsv(){const rows=[['Evento','Attore','Dettagli','Data'],...events.map(e=>[labels[e.event_type]||e.event_type,e.actor_user_id||'',JSON.stringify(e.metadata||{}),new Date(e.created_at).toLocaleString('it-IT')])];const csv=rows.map(r=>r.map(v=>'"'+String(v).replaceAll('"','""')+'"').join(',')).join('\n');const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));a.download='docchaser-audit.csv';a.click();URL.revokeObjectURL(a.href)}
 return <Page title="Security & Compliance" description="Controlla accesso, audit e conservazione delle attività dello studio.">
 <div className="grid" style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(280px,1fr))',gap:16}}>
  <div className="card"><h3>Account</h3><p className="muted">{email||'Account autenticato'}</p><button className="btn" disabled={busy} onClick={changePassword}>Cambia password</button><p className="muted" style={{marginTop:10}}>La nuova password viene gestita direttamente da Supabase Auth.</p></div>
  <div className="card"><h3>Conformità</h3><p>Audit organizzativo separato per studio.</p><p className="muted">La retention configurata nelle impostazioni resta il riferimento per i dati operativi.</p>{(role==='owner'||role==='admin')&&<button className="btn" disabled={busy} onClick={cleanup}>Esegui pulizia audit &gt;365 giorni</button>}</div>
 </div>
 <div className="card" style={{marginTop:16}}><div style={{display:'flex',gap:10,justifyContent:'space-between',alignItems:'center',flexWrap:'wrap'}}><div><h3>Activity log</h3><p className="muted">Ultime 200 attività dello studio.</p></div><div style={{display:'flex',gap:8}}><select value={filter} onChange={e=>setFilter(e.target.value)}><option value="">Tutti gli eventi</option>{Object.entries(labels).map(([k,v])=><option key={k} value={k}>{v}</option>)}</select><button className="btn" onClick={exportCsv}>Esporta CSV</button></div></div><div style={{overflowX:'auto'}}><table className="table"><thead><tr><th>Evento</th><th>Attore</th><th>Dettagli</th><th>Quando</th></tr></thead><tbody>{events.map(e=><tr key={e.id}><td><b>{labels[e.event_type]||e.event_type}</b></td><td className="muted">{e.actor_user_id||'Sistema'}</td><td className="muted">{e.metadata?.note||e.metadata?.email||e.metadata?.days||''}</td><td className="muted">{new Date(e.created_at).toLocaleString('it-IT')}</td></tr>)}{!events.length&&<tr><td colSpan={4} className="muted">Nessun evento.</td></tr>}</tbody></table></div></div>
 {msg&&<div className="badge green" style={{marginTop:12}}>{msg}</div>}{err&&<div className="badge red" style={{marginTop:12}}>{err}</div>}
 </Page>
}
